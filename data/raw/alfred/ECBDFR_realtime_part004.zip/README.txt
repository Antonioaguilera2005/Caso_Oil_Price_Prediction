-------------------------------------------------------------------
Series ID: ECBDFR
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=ECBDFR
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations by Real-Time Period
File Created: 2026-11-14 12:40 PM CST
-------------------------------------------------------------------

--------------------------------------------------------------------  ---------------  -------------
Title                                                                 Real-Time Start  Real-Time End
ECB Deposit Facility Rate for Euro Area                               2021-03-11       Current
Source
European Central Bank                                                 2021-03-11       Current
Release
Key ECB Interest Rates                                                2021-03-11       Current
Units
Percent                                                               2021-03-11       Current
Frequency
Daily, 7-Day                                                          2021-03-11       Current
Seasonal Adjustment
Not Seasonally Adjusted                                               2021-03-11       Current
Notes
The rate on the deposit facility, which banks may use to make         2021-03-11       Current
overnight deposits with the Eurosystem. Data refer to the changing
composition of the Euro Area, taking into account the composition of
the euro area at the time to which the statistics relate. For more
details, see the ECB Statistics Bulletin's General Notes
(https://sdw.ecb.europa.eu/reports.do?node=10000023).  Copyright,
2021, European Central Bank (ECB). Reprinted with permission.
--------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2026-08-25
2026-08-26
2026-08-27
2026-08-28
2026-08-31
2026-09-01
2026-09-02
2026-09-03
2026-09-04
2026-09-07
2026-09-08
2026-09-09
2026-09-10
2026-09-11
2026-09-14
2026-09-15
2026-09-16
2026-09-17
2026-09-18
2026-09-21
2026-09-22
2026-09-23
2026-09-24
2026-09-25
2026-09-28
2026-09-29
2026-09-30
2026-10-01
2026-10-02
2026-10-05
2026-10-06
2026-10-07
2026-10-08
2026-10-09
2026-10-12
2026-10-13
2026-10-14
2026-10-15
2026-10-16
2026-10-19
2026-10-20
2026-10-21
2026-10-22
2026-10-23
2026-10-26
2026-10-27
2026-10-28
2026-10-29
2026-10-30
2026-11-02
2026-11-03
2026-11-04
2026-11-05
2026-11-06
2026-11-09
2026-11-10
2026-11-11
2026-11-12
2026-11-13
2026-11-14
----------

